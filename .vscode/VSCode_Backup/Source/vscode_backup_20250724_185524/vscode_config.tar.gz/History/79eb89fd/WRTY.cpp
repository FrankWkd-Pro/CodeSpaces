/*
 * > CPP Code Snippet <
 * > Powered by Microsoft Visual Studio Code <
 *
 * @Author    FrankWKD (wangkedi01)
 * @Date      2025-07-14
 * @Network   "https://oj.czos.cn/contest/problem?id=25410&pid=2&_pjax=%23p0"
 * @License   GNU General Public License 2.0
 * @Platform  [Frank]iMac Ubuntu Pro 24.04 LTS
 * @FileName  T3[100pts].cpp
 * @FilePath  /media/frank/FrankW/_default/_Mine!/Working/code-spaces/czos/CSP-S_Practise/Lesson1/T3[100pts].cpp
 * @Solution  --
 */

// #pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
struct node {
    int v, d, a;
} a[N];

struct range {
    int e, b;
} b[N];
int p[N];
int n, m, len, v;
int cnt, T, res int pf(int x) {
    return x * x;
}
bool check(int di, int vi, int ai, int ed) {
    return pf(vi) + 2 * ai * (ed - di) > pf(v);
}
pair<int, int> fin(int di, int vi, int ai) {
    int t = lower_bound(p + 1, p + m + 1, di) - p;
    if (ai > 0) {
        int l = t;
        int r = m;
        while (l <= r) {
            int mid = l + r >> 1;
            if (check(di, vi, ai, p[mid]))
                r = mid - 1;
            else
                l = mid + 1;
        }
        return {l, m};
    }
    if (ai < 0) {
        int l = t, r = m, mid;
        while (l <= r) {
            mid = l + r >> 1;
            if (check(di, vi, ai, p[mid]))
                l = mid + 1;
            else
                r = mid - 1;
        }
        return {t, l - 1};
    }
}
bool cmp(range r1, range r2) {
    return r1.e < r2.e;
}
int solve() {
    sort(b + 1, b + cnt + 1, cmp);
    int res = 0, ls = -1;
    for (int i = 1; i <= cnt; i++) {
        if (b[i].b > last) {
            res++;
            ls = b[i].e;
        }
    }
    return m - res;
}

int main() {
    // freopen("sample.in","r",stdin);
    // freopen("sample.out","w",stdout);
    // ios::sync_with_stdio(false);
    // cin.tie(0); cout.tie(0);
    cin >> T;
    while (T--) {
    }
    // fclose(stdin);
    // fclose(stdout);
    return 0;
}