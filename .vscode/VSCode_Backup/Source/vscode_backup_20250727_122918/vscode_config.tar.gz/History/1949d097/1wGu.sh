cd /home/frank/文档/Blog_FrankWkd/blog
hexo clean
hexo g
hexo d
