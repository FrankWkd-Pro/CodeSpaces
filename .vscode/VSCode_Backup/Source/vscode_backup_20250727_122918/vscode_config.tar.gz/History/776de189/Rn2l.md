---
title: About ME
date: 2025-07-25 20:56:02
tags:
---

# $\mathfrak{About\ Me}_{\tiny{\mathsf{about\ Me}}}$
初二，坐标JL-CC，热衷于倒腾新玩意儿.
![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&size=30&pause=10&color=321BD7C5&width=435&lines=Think+Twice.)
## My Luogu
### [Luogu@lwj54joy](https://www.luogu.com.cn/user/845400#practice) 
![](https://badges.luogu.piterator.com/badge/user/845400/name?style=for-the-badge) ![](https://badges.luogu.piterator.com/badge/user/845400/ranking?style=for-the-badge) ![](https://badges.luogu.piterator.com/badge/user/845400/passed-problem-count?style=for-the-badge)

[![Lwj54joy的练习情况](https://api.jerryz.com.cn/practice?id=845400)](https://www.luogu.com.cn/user/845400#practice)
## My Github
### [Github@FrankWkd-Pro](https://github.com/FrankWkd-Pro/)
### Commit Chart 
![](https://raw.gitmirror.com/FrankWkd-Pro/FrankWkd-Pro/6c106fc50ff4c147c9f3857356600a2038550cbf/profile-3d-contrib/profile-night-view.svg)

## My Blog
### [FrankWkd's Blog | 三思而后行](https://frankwkd.pages.dev/)

## My CodeForces
### [CodeForces@FrankWkd](https://codeforces.com/profile/FrankWkd)

## My Cnblogs (现在荒了，欢迎考古)
### [Cnblogs@FrankWkd](https://www.cnblogs.com/FrankWKD)