---
title: CSP-S 01 做题记录
mathjax: true
date: 2025-07-12 06:42:14
tags: 
- C++
categories:
- 做题记录
- czos
---
# T1 禁卫军
:::details 点击展开题面
### A. 禁卫军  

#### 题目描述  
数字王国正在挑选最强壮，最独一无二的勇士作为国王的禁卫军。  

有 $n$ 个数字士兵参与了这次选拔，分别为 $w_1, w_2, \dots, w_n$。其中可能存在多个相同的数字士兵，选拔的条件是：如果这个数不能被剩下的 $n - 1$ 个数整除，就可以成为禁卫军。  

请问，其中会有多少个士兵能顺利加入禁卫军。  


#### 输入  
第一行读入一个整数 $n$。  

第二行读入 $n$ 个整数表示所有数字士兵 $w_i$，用空格隔开。  


#### 输出  
输出一个整数，表示有多少个士兵能顺利加入禁卫军。  


#### 样例  
**样例 1**  
- 输入： 

```
5  
3 7 9 16 17  
```

输出：  

```
4  
```

**样例 2**  
输入：  
```
5  
1 2 3 4 5  
```
输出：  
```
1  
```

**样例 3**  
输入：  
```
5  
2 2 3 3 5  
```
输出：  
```
1  
```


#### 说明  
- **样例 1 解释**：  
  数列中 $3, 7, 16, 17$ 不能被数列中其它整数整除，$9$ 会被 $3$ 整除，所以有 $4$ 个。  

- **数据规模**：  
  - $1 \le w_i \le 10^6$。  
  - 对于 $50\%$ 的数据：$1 \le n \le 10000$。  
  - 对于 $100\%$ 的数据：$1 \le n \le 100000$。  

:::

## T1 Sol
**问题描述**：  
求有多少个数，不能被自己以外的其他数字整除。  


#### 部分分思路  
若暴力枚举，需遍历每个数与其他数的整除关系，时间复杂度为 $\mathcal{O}(n^2)$  。  


#### 满分思路  
样例隐含规律：若存在 `1`，则其他数会被 `1`整除；但多个 `1`间可互相整除。  

可借鉴**埃筛**思想，标记不符合要求的数：  
 
1. 先将数排序，再从小到大遍历。对每个未被标记的数，标记其所有倍数为「不符合要求」（因这些倍数能被当前数整除）。  
2. 枚举到某数时，若未被标记为「不符合要求」，则该数可能符合条件。  
3. 若存在相等的数，第 $1$ 个虽可能未被标记，但相等数间可互相整除，**一定不符合要求** 。  

:::warning 注意！
对于相同的数，他们可以互相牵制，都不算做合法答案。

:::

## T1 Code

```cpp
/*
 * > CPP Code Snippet <
 * > Powered by Microsoft Visual Studio Code <
 *
 * @Author    FrankWKD (wangkedi01)
 * @Date      2025-07-09
 * @Network   "https://oj.czos.cn/contest/problem?id=25410&pid=0"
 * @License   GNU General Public License 2.0
 * @Platform  [Frank]iMac Ubuntu Pro 24.04 LTS
 * @FileName  T1.cpp
 * @FilePath  /media/frank/FrankW/_default/_Mine!/Working/code-spaces/czos/CSP-S_Practise/Lesson1/T1.cpp
 * @Solution  --
 */

// #pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
int a[1010100];
int n;
bool f[1010100];
int ans;
int main() {
    // freopen("sample.in","r",stdin);
    // freopen("sample.out","w",stdout);
    // ios::sync_with_stdio(false);
    // cin.tie(0); cout.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    sort(a + 1, a + 1 + n);
    if (a[1] == 1) {
        if (a[2] != 1)
            cout << 1;
        else
            cout << 0;
        return 0;
    }
    for (int i = 1; i <= n; i++) {
        if (!f[a[i]] and a[i] != a[i + 1])  // 如果相邻的相等还不行呢
            ans++;
        for (int j = a[i]; j <= a[n]; j += a[i]) {
            f[j] = 1;
        }
    }
    cout << ans << endl;
    // fclose(stdin);
    // fclose(stdout);
    return 0;
}
```

# T2 [CSP-S2024]决斗
:::details 点击展开题面
# P11231 [CSP-S 2024] 决斗

## 题目描述

今天是小 Q 的生日，他得到了 $n$ 张卡牌作为礼物。这些卡牌属于火爆的“决斗怪兽”，其中，第 $i$ 张卡代表一只攻击力为 $r_i$，防御力也为 $r_i$ 的怪兽。

一场游戏分为若干回合。每回合，小 Q 会选择某只怪兽 $i$ 以及**另一只**怪兽 $j(i \neq j)$，并让怪兽 $i$ 向怪兽 $j$ 发起攻击。此时，若怪兽 $i$ 的攻击力小于等于怪兽 $j$ 的防御力，则无事发生；否则，怪兽 $j$ 的防御被打破，怪兽 $j$ 退出游戏不再参与到剩下的游戏中。一只怪兽在整场游戏中**至多**只能发起一次攻击。当未退出游戏的怪兽都已发起过攻击时，游戏结束。

小 Q 希望决定一组攻击顺序，使得在游戏结束时，未退出游戏的怪兽数量尽可能少。

## 输入格式

输入的第一行包含一个正整数 $n$，表示卡牌的个数。

输入的第二行包含 $n$ 个正整数，其中第 $i$ 个正整数表示第 $i$ 个怪兽的攻击力及防御力 $r_i$。

## 输出格式

输出一行包含一个整数表示游戏结束时未退出游戏的怪兽数量的最小值。

## 输入输出样例 #1

### 输入 #1

```
5
1 2 3 1 2
```

### 输出 #1

```
2
```

## 输入输出样例 #2

### 输入 #2

```
10
136 136 136 2417 136 136 2417 136 136 136
```

### 输出 #2

```
8
```

## 说明/提示

**【样例 1 解释】**

其中一种最优方案为：第一回合让第 $2$ 只怪兽向第 $1$ 只怪兽发起攻击，第二回合让第 $5$ 只怪兽向第 $4$ 只怪兽发起攻击，第三回合让第 $3$ 只怪兽向第 $5$ 只怪兽发起攻击。此时没有退出游戏的怪兽都进行过攻击，游戏结束。可以证明没有更优的攻击顺序。

**【样例 3】**

见选手目录下的 duel/duel3.in 与 duel/duel3.ans。

该样例满足 $\forall 1 \leq i \leq n, r_i \leq 2$。

**【样例 4】**

见选手目录下的 duel/duel4.in 与 duel/duel4.ans。

**【数据范围】**

对于所有测试数据，保证：$1 \leq n \leq 10^5$，$1 \leq r_i \leq 10^5$。

|   测试点    |     $n$     |    $r_i$    |  特殊性质  |
| :---------: | :---------: | :---------: | :--------: |
|  $1\sim 4$  |  $\leq 10$  | $\leq 10^5$ | 无特殊性质 |
| $5\sim 10$  | $\leq 10^5$ |  $\leq 2$   | 无特殊性质 |
| $11\sim 15$ |  $\leq 30$  | $\leq 10^5$ | 特殊性质 A |
| $16\sim 20$ | $\leq 10^5$ | $\leq 10^5$ | 无特殊性质 |

特殊性质 A：保证每个 $r_i$ 在可能的值域中独立均匀随机生成。

:::

## T2 Sol

采用**贪心策略**，结合双指针配对：  
假设存在三个数满足 $a < b < c$，若 $c$ 选择击败 $a$，则 $b$ 无可以击败的对象（因 $b$ 仅能击败比它小的数，而比 $b$ 小的 $a$ 已被 $c$ 击败 ）。  
基于此规律，可用双指针法对数组排序后进行配对，优化剩余数的计算逻辑，得到最少剩余数量。  

（注：完整实现需先对数组排序，再通过指针模拟攻击配对过程，此处为核心思路提炼 。）

## T2 Code

```cpp
/*
 * > CPP Code Snippet <
 * > Powered by Microsoft Visual Studio Code <
 *
 * @Author    FrankWKD (wangkedi01)
 * @Date      2025-07-09
 * @Network   "https://oj.czos.cn/contest/problem?id=25410&pid=1"
 * @License   GNU General Public License 2.0
 * @Platform  [Frank]iMac Ubuntu Pro 24.04 LTS
 * @FileName  T2.cpp
 * @FilePath  /media/frank/FrankW/_default/_Mine!/Working/code-spaces/czos/CSP-S_Practise/Lesson1/T2.cpp
 * @Solution  -
 */

// #pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
const int N = 100005;
int a[N], n;
bool cmp(int m, int b) {
    return m > b;
}
int main() {
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
    }
    sort(a + 1, a + n + 1, cmp);
    int ans = n;
    for (int i = n, j = n; i >= 1; i--) {
        if (a[i] > a[j]) {
            j--;
            ans--;
        }
    }
    printf("%d", ans);
    return 0;
}
```

# T3 