cd /home/frank/文档/Blog_FranWkd/blog
hexo clean
hexo g
hexo d
