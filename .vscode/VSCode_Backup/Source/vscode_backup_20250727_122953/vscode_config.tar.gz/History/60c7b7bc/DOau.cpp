/*
 * @Author    FrankWKD (wangkedi01)
 * @Date      2025-06-21
 * @Source    "--"
 * @License   GNU General Public License 2.0
 * @FileName  Template.cpp
 * @FilePath  /media/frank/FrankW/_default/_Mine!/Working/code-spaces/czos/Tarjan_SCC/Template.cpp
 * @Solution  Tarjan求SCC模板，同T1
 */

// #pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
const int N = 1e4 + 10, M = 5e4 + 10;
struct node {
    int to, nxt;
} a[M];

int pre[N], k = 0;
int dfn[N],
    int main() {
    // ios::sync_with_stdio(false);
    // cin.tie(0); cout.tie(0);

    return 0;
}