---
title: MY LIBRARY
mathjax: true
date: 2025-07-11 18:46:31
tags: 
- Others
categories:
- 其他
---
## 这是我的网页库
##### Updated AT 2024.09.22。
#### $BY：Lwj54joy(FrankWKD)$
#### $你是第$ ![](https://saobby.pythonanywhere.com/api/webcounter?id=stO10RwaTSLD35h8)$个犇到翻这里的人$
[//]:(网站访问量统计台控制令牌：njamM06qjyqkT752JvwTucjTDD4psKsGIoVrJ97MnspfQ2z1gTYgNrTCcRFRVTJs)
----
朝代2048存档：apx0-k7tp-0749-mejf-jswo-eu9s-210z-48py  
朝代2048存档II：alp4-c461-9kc5-2iva-y90d-52uf-w5kz-29si  
朝代2048存档III(进度：五代十国): 2yn8-s84w-fcgt-u0rn-tq5j-jokm-lbxz-e2ub
[别点`I`](btbxx.cc)  
[别点`II`](tao.sex)  
[别点`III`](xxav.tv)  
[别点`IV`](queensect.com)  

----
## TOP [果核导航](https://dh.ghxi.com/)
----
### ${{\color{000000}快捷方式\ <\ Quick\ Start\ >}}$
- [U盘双分区启动盘制作 - 不同分区互不影响 - 一个存储，一个启动](https://blog.csdn.net/Leisurelyc/article/details/93603682)
- [AcWing](https://www.acwing.com/about/)
- [东方博宜OJ](https://oj.czos.cn/)
- [东方博宜考试平台](https://v.kaoshixing.com/exam/pc/home/#/)
- [GDB Online Debgger](https://www.onlinegdb.com/)
- [Accoders](http://www.accoders.com/)
- [YACS](https://iai.sh.cn/)
- [Luogu-Main](https://www.luogu.com.cn/)
- [Luogu-ArticlesHall](https://www.luogu.com.cn/article)
- [Luogu-My Team](https://www.luogu.com.cn/user/845400#mine.team)
- [Luogu-My Article](https://www.luogu.com.cn/article/mine)
- [Luogu-My Favourite](https://www.luogu.com.cn/user/845400#favorite)
- [Luogu-My Practise](https://www.luogu.com.cn/user/845400#practice)
- [网易云课堂](https://study.163.com/)
- [AirPortal空投快传](https://airportal.cn/)
- [SejdaPDF在线编辑无需登录](https://www.sejda.com/)
- [SlowRoads](https://slowroads.io/)
----
----
### ${{\color{000000}工具\ <\ Tools\ >}}$
- $\texttt{{\color{F1C40F}小工具}}$：
  - [连点器](https://sourceforge.net/projects/orphamielautoclicker/)
  - [【顶】MSCN所有Windows官方镜像ISO版本提供BT高速下载](https://msdn.itellyou.cn/)
  - [临时邮件](https://mail.tm/zh)
  - [Vlink - 通过一个永久链接/二维码, 聚合所有链接/图片](https://vlink.cc/)
  - [Tailchat Nightly - 开源 - 可供高度自定义 - 完全独属于私人团队的沟通平台](https://nightly.paw.msgbyte.com/main/personal/friends)
  - [原题机 - 全网原题搜索 - 关键词原题搜索](http://yuantiji.ac/zh/)
  - [原题机的源码（现储存在Github中）](https://github.com/fjzzq2002/is-my-problem-new)
  - [Windows激活](https://massgrave.dev/)
  - [Github下载加速](https://ghproxy.net/)
  - [格式转换器 - 个性化转换 - 最大1GB - 无需登录](https://www.aconvert.com/cn/video/extract/)
  - [几乎所有的可能的文件都能互相转换 - 讯飞转换（无需登录且小文件免费）](https://app.xunjiepdf.com/en/)
  - [4小时临时Clash魔法上网订阅链接](https://github.com/crossxx-labs/free-proxy)
  - [致美化 - 电脑最全美化平台](https://zhutix.com/tag/win10-zhuti/#)
  - [Github下载加速器 - 网页直接下载无需任何软件](https://ghproxy.net/)
  - [浏览器内核检测](https://www.ghxi.com/llq)
  - [良心剪贴板](https://netcut.cn/1iaoubrtu)
  - [最全数学工具 无需登录 平替Geogebra 不能下载](https://www.desmos.com/?lang=zh-CN)
  - [鼠标外观美化大全](https://zhutix.com/tag/cursors/)
  - [性能/手速测试大全](https://www.arealme.com/reaction-test/cn/)
  - [SejdaPDF在线编辑无需登录](https://www.sejda.com/)
  - [文本比较器](https://www.diffchecker.com/)
  - [超全种类加密器](https://www.ff98sha.me/tools/encoder/)
  - [base64编码/解码转换](https://tool.ip138.com/base64/)
  - [LaTeX参考器](https://www.latexlive.com/home)
  - [随机壁纸](https://iw233.cn/main.html)
  - [Oler DB NG获奖查询](https://oier.baoshuo.dev/?utm_medium=oierdb-banner)
  - [各种超好看的ASCII文字生成器（在线）](http://www.network-science.de/ascii/)
- $\texttt{{\color{F1C40F}破解}}$：
  - [懒得勤快的博客 - 软件大全](https://masuit.net/)
  - [52pojie.cn吾爱破解](https://www.52pojie.cn/)
  - [果核剥壳 - 简介但不简单的IT博客](https://www.ghxi.com/)
  - [小可博客 - 收集冷门但高级的绿色软件](https://www.keke.moe/)
  - [APP热 - 计算机、手机软件的收集、分享与汉化、修改等技术交流。
](https://apphot.cc/)
  - [Qiuquan's Blog - 技术控&软件控的水帘洞<软件绿化、精简与优化>](http://www.qiuquan.cc/)
  - [爱免费吧好站导航 - 免费收录有用好用的网站](https://www.imf8.cn/)
  - [秋叶资源网 - 不断更新最新IT资源](https://www.qybhl.com/)
  - [绿色便携软件和精品软件的社区论坛](https://www.lvruanhome.com/)
  - [落尘之木 - 小众但值得探寻的网站](https://www.luochenzhimu.com/)
  - [爱好论坛 - 比吾爱破解还全的论坛](https://www.aihao.cc/forum.php)
  - [AI工具集](https://ai-bot.cn/)
  - [蓝点网 - 给你感兴趣的IT资讯和软件](https://www.landiannews.com/)
  - [果核导航 - 收藏好网址的摸鱼天地](https://dh.ghxi.com/)

- $\texttt{{\color{F1C40F}项目工具}}$：
  - [Crx搜搜 - 一个牛X的Google扩展和应用商店](https://www.crxsoso.com/)

- $\texttt{{\color{F1C40F}测试}}$：

  - [MBTI官网免费](https://www.16personalities.com/ch/)
  - [APESK-64种人格理论测试](http://www.apesk.com/p/index.asp?mq=&re=yes)

- $\texttt{{\color{F1C40F}传输}}$：
  - [洛谷图床](https://www.luogu.com.cn/paste)
  - [AirPortal空投快传](https://airportal.cn/)
  - [WormHole无需登录最大10G](https://wormhole.app/)

- $\texttt{{\color{52C41A}工具箱}}$：

  - [平平无奇的工具箱](http://tool.mkblog.cn/)
  - [超好用工具集](http://www.atoolbox.net/)
  - [一些有趣有巨好用的网站/软件合集](https://www.luogu.com/paste/md28al7y)
  - [你想得到的全都有（游戏，学习，工具集）](https://www.luogu.com/paste/jal6px5f)
----
----
### ${{\color{000000}项目工程\ <\ Programming\ >}}$
- ${\color{52C41A}C++模板库\ <C++\ Templates\ >}$
  - [OI Wiki-代码库](https://oi-wiki.org/)
  - [#1模板库](https://upload-file.xcpcio.com/Code-Library/NJU-Calabash-Release-For-EC-Final.pdf)
  - [#2模板库](https://upload-file.xcpcio.com/Code-Library/ECNU-F0RE1GNERS-template.pdf)
  - [#3模板库](https://upload-file.xcpcio.com/Code-Library/NJU-Calabash-Release-For-EC-Final.pdf)
  - [SUPER 快读(非整活勿用)](https://www.luogu.com.cn/paste/ilt13pl4)
- ${\color{52C41A}C++游戏+教程 <\ C++GameStudying\ >}$
  - [全种类加密器](https://www.ff98sha.me/tools/encoder/)
  - [base64编码/解码转换](https://tool.ip138.com/base64/)
  - [c++游戏：王权](https://www.luogu.com.cn/paste/rsupsp43)
- ${\color{52C41A}比赛与算法\ <\ Comptitions\ and\ Algorithms>\ }$
  - [KMPnext数组求法](https://blog.csdn.net/hi25779/article/details/89504487)
  - [KMP算法详解建议搭配上方传送门（）](https://www.cnblogs.com/cherryg/p/14474463.html)
  - [CLIST - 记录全网OI比赛日程](https://clist.by/?view=list)
  - [知识点总结](https://www.luogu.com/article/bfz5g65h)
  - [NOI大纲](https://www.noi.cn/upload/resources/file/2023/03/15/1fa58eac9c412e01ce3c89c761058a43.pdf)
  - [CSP初赛知识点梳理](https://www.luogu.com.cn/blog/334586/csp-pre-knowledge)
  - [高阶算法笔记](https://www.luogu.com.cn/blog/command-block/blog-suo-yin-zhi-ding-post)
  - [复赛时要记住的 30 句话](https://www.luogu.com.cn/blog/zyf2004/fu-sai-shi-yao-ji-zhu-di-30-gou-hua)
  - [高中数学笔记](https://www.luogu.com.cn/blog/hugocaicai/gao-zhong-shuo-xue-xue-xi-bi-ji) 

----
----
### ${{\color{000000}编辑优化\ <\ Optimize\ and\ Writing\ >}}$
- ${\color{33A3AA}编辑\ <\ Edit\ >}$

  - [如何使用Markdown?](https://www.luogu.com.cn/blog/luogu/how-to-use-markdown)
  - [MArkdown&流程图&脑图&思维导图在线编辑 ｜ 无需登录｜强大的同步功能](https://draw.io/)
  - [LateX图片转换文字（Markdown也行，需登录每天限制次数）](https://simpletex.cn/ai/latex_ocr)
  - [LateX编辑+图片公式识别（不限次数但是不能识别Markdown）](https://math-editor.online/)
  - [Luogu题解格式化工具](https://tj.imken.dev/)
  - [LateX全网最全指南](https://www.luogu.com.cn/article/1gxob6zc)
  - [LaTeX公式在线编辑](https://www.latexlive.com/home)
  - [题解指南](https://studyingfather.blog.luogu.org/blog-written-guide)
  - [个人主页常用技巧](https://wls.blog.luogu.org/ge-ren-zhu-ye-chang-yong-ji-qiao)
  - [洛谷日报](https://www.luogu.com/discuss/48491)
  - [RE：从零开始搭建自己的博客](https://www.luogu.com.cn/blog/12cow/wordpress)
  - [能发题解的题目总览](https://luogu.codingoier.com/solution)

- ${\color{33A3AA}洛谷优化插件+脚本\ <\ Luogu\ Optimize\ Functions\ +\ Codes\ >}$

  - [番茄阅读网爬虫txt小说]()
  - [Windows文件快速定位软件](https://www.voidtools.com/zh-cn/)
  - [截屏代码](https://github.com/binbyu/CaptureTool/blob/master/README.md)
  - [nb音乐下载器](https://music.liuzhijin.cn/)
  - [音乐离线播放网站（进入时需要使用网络初始化）](https://tools.liumingye.cn/music/)
  - [极简插件](https://chrome.zzzmh.cn/index)
  - [免费的翻译插件点击即下载 - 划词翻译 - 悬停翻译 - 动态翻译 - 一键翻译整站](https://www.luogu.com.cn/api/team/downloadFile/et37z3qm)
     - 下载后请打开开发者模式并将其拖入（直接拖入不改动）
  - 插件请移步至：团队80686
----
----
### ${{\color{000000}休闲娱乐\ <\ Playing\ >}}$
- ${\color{52C41A}网页游戏\ <\ Website\ Games\ >}$

  - [网站推荐](https://lkssite.vip/)
  - [网盘中的游戏（来自Steam）（度盘+夸克盘+迅雷盘）](https://blog.csdn.net/weixin_74774974/article/details/136772239)
  - [朝代2048 - 有5\*5和4*4版本!](https://oprilzeng.com/2048/full/)
  - [2048英文版 - 可以用技能（撤回，交换，删除...）](https://play2048.co/)
  - [Steam游戏免费下载](https://steamunlocked.net/underground-garage-free-download/)
  - [少年陈哲-番外篇 - 洛谷小说](https://www.luogu.com/article/rax2ktnd)
  - [休闲娱乐类英文游戏](https://dordlewordle.com/)
  - [SlowRoads](https://slowroads.io/)
  - [BeatStage - 免费在线音游](https://www.beatstage.com/)
  - [powdertoy - 在线沙盒世界](https://powdertoy.co.uk/Wasm.html)
  - [powdertoy_Download - 沙盒世界软件](https://powdertoy.co.uk/)
  - [Sandspiel.club](https://sandspiel.club/)
  - [地下探险队](http://ta.maougame.com/)
  - [digdig.io](https://digdig.io/)
  - [心跳水立方](https://missile-game.bwhmather.com/)
  - [网络游戏合集](https://www.luogu.com/paste/ck20wfcs)
  - [游戏合集2（蛮全的）](https://www.luogu.com/paste/v91ou83u)
  - [C++赌命游戏压缩包等](https://www.luogu.com.cn/problem/U496766)
  - [仿`Osu!`音游下载](https://github.com/Entiesci/TurbowarpGame-TapDrop/releases/download/v1.1.1/Phigros.tap.drop-inf.html)
  - [Isle of Tune - 城市建造游戏可存档](https://isleoftune.com/)
  - [osu!音游源码以及多平台（包括移动端）下载（Github）](https://github.com/ppy/osu/releases/)
  - [osu!音游直接高速下载Windows64位安装包（可能失效）（Github高速链接）](https://gh.api.99988866.xyz/https://github.com/ppy/osu/releases/download/2025.101.0/install.exe)
  - [osu!音游直接官网下载Windows64位安装包（尽量用上面的，这个也就几KB一秒）（Github）](https://github.com/ppy/osu/releases/latest/download/install.exe)
  - [osu!官网官方下载多平台（包括移动端）（优先选这个）](https://osu.ppy.sh/home/download)
  - [osu!官网（谱面+下载）](https://osu.ppy.sh/home/download)
  - [仿Phigros的音游](https://phitogether.fun/#/loading)


- ${\color{52C41A}摸鱼\ <\ Fishing\ >}$

  - [MC wiki](https://minecraft.fandom.com/zh/wiki/Minecraft_Wiki)
  - [摸鱼网站 - 收集各大热榜和...](https://sbmy.fun/)
  - [摸鱼导航 - 收录最全摸鱼网站](https://www.cnblogs.com/FHenryh/p/moyu.html)
  - [解压圆形图](https://www.koalastothemax.com/)
  - [Owllook - 在线免费纯净电纸书阅读/网文阅读+很难找到的《某某》](https://owllook2.yueing.org/owllook_content?url=https://www.biquge365.net/chapter/564741/49050527.html&name=7%E3%80%81%E4%BE%BF%E7%AD%BE%E6%9D%A1&chapter_url=https://www.biquge365.net/newbook/564741/&novels_name=%E6%9F%90%E6%9F%90)
  - [Minecraft世界观](https://www.luogu.com.cn/paste/1i899qaa)
  - [Harry Potter的各类咒语合集](https://www.luogu.com.cn/paste/ccwafoje)
  - [随机壁纸](https://iw233.cn/main.html)
  - [随机动漫风景图](https://t.mwm.moe/fj/)
  - [YORG3.io联机塔防](https://yorg3.io/)
  - [星夜小游戏平台(其中的《小小炼金术师》超级适合摸鱼/打发时间)!](https://xingye.me/game/index.php)
  - [矮人要塞，一款免费的超硬核类roguelike游戏](https://www.52pojie.cn/thread-1162663-1-1.html)
  - [小游戏和游戏攻略+小众工具](https://www.luogu.com/paste/eseohmye)
![](https://t.mwm.moe/fj/)


----
----
- ${\color{52C4F0}LaTeX颜色对照表\ <\ Colouring\ Compare\ >}$

$$
\def\arraystretch{1.2}
\begin{array}{|c|l|l||c|l|l|} \hline
颜色 & 十六进制 & RGB值 & 颜色 & 十六进制 & RGB值  \\ \hline
\color{#52C41A}\text{AC绿} & \text{52C41A} & \text{(82,196,26)} & \color{#FE4C61}\text{入门红} & \text{FE4C61} & \text{(254,76,97)} \\ \hline
\color{#E74C3C}\text{WA红} & \text{E74C3C} & \text{(231,76,60)} & \color{#F39C11}\text{普及-橙} & \text{F39C11} & \text{(243,156,17)} \\ \hline
\color{#9D3DCF}\text{RE紫} & \text{9D3DCF} & \text{(157,61,207)} & \color{#FFC116}\text{普及黄} & \text{FFC116} & \text{(255,193,22)}\\ \hline
\color{#FADB14}\text{CE黄} & \text{FADB14} & \text{(250,219,20)} & \color{#52C41A}\text{普及+提高 绿} & \text{52C41A} & \text{(82,196,26)} \\ \hline
\color{#052242}\text{TLE黑} & \text{052242} & \text{(5,34,66)} & \color{#3498DB}\text{提高+省选-蓝} & \text{3498DB} & \text{(52,152,219)} \\ \hline
\color{#052242}\text{MLE黑} & \text{052242} & \text{(5,34,66)} & \color{#9D3DCF}\text{省选紫} & \text{9D3DCF} & \text{(157,61,207)}  \\ \hline
\color{#052242}\text{OLE黑} & \text{052242} & \text{(5,34,66)} & \color{#0E1D69}\text{NOI黑} & \text{0E1D69} & \text{(14,39,105)}   \\ \hline
\color{#0E1D69}\text{UKE蓝} & \text{0E1D69} & \text{(14,29,105)} & \color{#BFBFBF}\text{未评定灰} & \text{BFBFBF} & \text{(191,191,191)} \\ \hline \hline 
\color{#8E44AD}\text{紫名} & \text{8E44AD} & \text{(142,68,173)} & \color{#52C41A}\text{排行绿} & \text{52C41A} & \text{(82,196,26)} \\ \hline
\color{#E74C3C}\text{红名} & \text{E74C3C} & \text{(231,76,60)} & \color{#F39C11}\text{排行橙} & \text{F39C11} & \text{(243,156,17)} \\ \hline
\color{#E67E22}\text{橙名} & \text{E67E22} & \text{(230,126,34)} & \color{#FADB14}\text{排行黄} & \text{FADB14} & \text{(250,219,20)} \\ \hline
\color{#5EB95E}\text{绿名} & \text{5EB95E} & \text{(94,185,94)} & \color{#E74C3C}\text{排行红} & \text{E74C3C} & \text{(231,76,60)}\\ \hline
\color{#0E90D2}\text{蓝名} & \text{0E90D2} & \text{(14,144,210)} & \color{#52C41A}\text{通过钩绿} & \text{52C41A} & \text{(82,196,26)} \\ \hline
\color{#BFBFBF}\text{灰名} & \text{BFBFBF} & \text{(191,191,191)} & \color{#E74C3C}\text{不通过叉红} & \text{E74C3C} & \text{(231,76,60)} \\ \hline
\hline 
\color{#E74C3C}\text{吉利红} & \text{E74C3C} & \text{(231,76,60)} & \color{#E74C3C}\text{官方比赛红} & \text{E74C3C} & \text{(231,76,60)} \\ \hline
\color{#5EB95E}\text{中平绿} & \text{5EB95E} & \text{(94,185,94)} & \color{#054310}\text{团队比赛绿} & \text{054310} & \text{(5,67,16)} \\ \hline
\color{#000000}\text{凶兆黑} & \text{000000} & \text{(0,0,0)} & \color{#3498DB}\text{个人比赛蓝} & \text{3498DB} & \text{(52,152,219)} \\ \hline \hline
\color{#8E44AD}\text{ACM制紫} & \text{8E44AD} & \text{(142,68,173)} & \color{#5EB95E}\text{Rated绿} & \text{5EB95E} & \text{(94,185,94)} \\ \hline
\color{#F1C40F}\text{IOI制黄} & \text{F1C40F} & \text{(241,196,15)} & \color{#5EB95E}\text{未开始绿} & \text{5EB95E} & \text{(94,185,94)} \\ \hline
\color{#F1C40F}\text{乐多制黄} & \text{F1C40F} & \text{(241,196,15)} & \color{#E74C3C}\text{已结束红} & \text{E74C3C} & \text{(231,76,60)} \\ \hline
\color{#F39C11}\text{OI制橙} & \text{F39C11} & \text{(243,156,17)} & \color{#4290D8}\text{进行中*} & \text{4290D8} & \text{(66,144,216)} \\ \hline \hline
\color{#EFEFEF}\text{背景灰} & \text{EFEFEF} & \text{(239, 239, 239)} & \color{#7F7F7F}\text{小字灰} & \text{7F7F7F} & \text{(127,127,127)} \\ \hline \hline 
\color{#0E90D2}\text{按钮蓝} & \text{0E90D2} & \text{(14,144,210)} & \color{#3498DB}\text{链接蓝} & \text{3498DB} & \text{(52,152,219)} \\ \hline 
\color{#DD514C}\text{按钮红} & \text{DD514C} & \text{(221,81,76)} & \color{#3498DB}\text{通过率蓝} & \text{3498DB} & \text{(52,152,219)} \\ \hline \hline 
\color{#FFE169}\text{金钩黄} & \text{FFE169} & \text{(255,225,105)} & \color{#F5CECD}\text{背景粉} & \text{F5CECD} & \text{(245,206,205)} \\ \hline
\color{#5EB95E}\text{绿钩绿} & \text{5EB95E} & \text{(94,185,94)} & \color{#C9E7C9}\text{背景绿} & \text{C9E7C9} & \text{(201,231,201)} \\ \hline
\color{#3498DB}\text{蓝钩蓝} & \text{3498DB} & \text{(52,152,219)} & \color{#CAEBFB}\text{背景蓝} & \text{CAEBFB} & \text{(202,235,251)} \\ \hline \hline 
\color{#3498DB}\text{题目来源蓝} & \text{3498DB} & \text{(52,152,219)} &\color{#7F7F7F}\text{灰色} & \text{7F7F7F} & \text{(127,127,127)} \\ \hline
\color{#E74C3C}\text{题目算法红} & \text{E74C3C} & \text{(231,76,60)}& \color{#FFFFFF}\text{白色} & \text{FFFFFF} & \text{(255,255,255)} \\ \hline
\color{#52C41A}\text{题目地点绿} & \text{52C41A} & \text{(82,196,26)}& \color{#000000}\text{黑色} & \text{000000} & \text{(0,0,0)} \\ \hline
\end{array}
$$