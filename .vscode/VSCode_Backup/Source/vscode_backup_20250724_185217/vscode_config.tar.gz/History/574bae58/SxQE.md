---
title: CSP-S 01 做题记录
mathjax: true
date: 2025-07-12 06:42:14
tags: 
- C++
categories:
- 做题记录
- czos
---
# T1 禁卫军
:::details 点击展开题面
### A. 禁卫军  

#### 题目描述  
数字王国正在挑选最强壮，最独一无二的勇士作为国王的禁卫军。  

有 $n$ 个数字士兵参与了这次选拔，分别为 $w_1, w_2, \dots, w_n$。其中可能存在多个相同的数字士兵，选拔的条件是：如果这个数不能被剩下的 $n - 1$ 个数整除，就可以成为禁卫军。  

请问，其中会有多少个士兵能顺利加入禁卫军。  


#### 输入  
第一行读入一个整数 $n$。  

第二行读入 $n$ 个整数表示所有数字士兵 $w_i$，用空格隔开。  


#### 输出  
输出一个整数，表示有多少个士兵能顺利加入禁卫军。  


#### 样例  
**样例 1**  
输入：  
```  
5  
3 7 9 16 17  
```  
输出：  
```  
4  
```  

**样例 2**  
输入：  
```  
5  
1 2 3 4 5  
```  
输出：  
```  
1  
```  

**样例 3**  
输入：  
```  
5  
2 2 3 3 5  
```  
输出：  
```  
1  
```  


#### 说明  
- **样例 1 解释**：  
  数列中 $3, 7, 16, 17$ 不能被数列中其它整数整除，$9$ 会被 $3$ 整除，所以有 $4$ 个。  

- **数据规模**：  
  - $1 \le w_i \le 10^6$。  
  - 对于 $50\%$ 的数据：$1 \le n \le 10000$。  
  - 对于 $100\%$ 的数据：$1 \le n \le 100000$。  


：：：

## T1 Sol
**问题描述**：  
求有多少个数，不能被自己以外的其他数字整除。  


#### 部分分思路  
若暴力枚举，需遍历每个数与其他数的整除关系，时间复杂度为 $\mathcal{O}(n^2)$  。  


#### 满分思路  
样例隐含规律：若存在 `1`，则其他数会被 `1` 整除；但多个 `1` 间可互相整除。  

可借鉴**埃筛**思想，标记不符合要求的数：  
 
1. 先将数排序，再从小到大遍历。对每个未被标记的数，标记其所有倍数为「不符合要求」（因这些倍数能被当前数整除）。  
2. 枚举到某数时，若未被标记为「不符合要求」，则该数可能符合条件。  
3. 若存在相等的数，第 $1$ 个虽可能未被标记，但相等数间可互相整除，**一定不符合要求** 。  
:::warning 注意！
对于相同的数，他们可以互相牵制，都不算做合法答案。

:::

## T1 Code

```cpp
/*
 * > CPP Code Snippet <
 * > Powered by Microsoft Visual Studio Code <
 *
 * @Author    FrankWKD (wangkedi01)
 * @Date      2025-07-09
 * @Network   "https://oj.czos.cn/contest/problem?id=25410&pid=0"
 * @License   GNU General Public License 2.0
 * @Platform  [Frank]iMac Ubuntu Pro 24.04 LTS
 * @FileName  T1.cpp
 * @FilePath  /media/frank/FrankW/_default/_Mine!/Working/code-spaces/czos/CSP-S_Practise/Lesson1/T1.cpp
 * @Solution  --
 */

// #pragma GCC optimize(3)
#include <bits/stdc++.h>
using namespace std;
int a[1010100];
int n;
bool f[1010100];
int ans;
int main() {
    // freopen("sample.in","r",stdin);
    // freopen("sample.out","w",stdout);
    // ios::sync_with_stdio(false);
    // cin.tie(0); cout.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    sort(a + 1, a + 1 + n);
    if (a[1] == 1) {
        if (a[2] != 1)
            cout << 1;
        else
            cout << 0;
        return 0;
    }
    for (int i = 1; i <= n; i++) {
        if (!f[a[i]] and a[i] != a[i + 1])  // 如果相邻的相等还不行呢
            ans++;
        for (int j = a[i]; j <= a[n]; j += a[i]) {
            f[j] = 1;
        }
    }
    cout << ans << endl;
    // fclose(stdin);
    // fclose(stdout);
    return 0;
}
```

# T2 