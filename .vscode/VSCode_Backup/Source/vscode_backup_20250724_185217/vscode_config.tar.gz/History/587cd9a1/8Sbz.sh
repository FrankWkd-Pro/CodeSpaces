cd /home/frank/文档/My_Blog_Web
hexo clean
hexo g
hexo s
