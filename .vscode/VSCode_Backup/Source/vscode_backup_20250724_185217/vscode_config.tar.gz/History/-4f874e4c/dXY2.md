---
title: 关于本博客的代码块功能说明&构建日志
mathjax: true
date: 2025-07-11 21:09:22
tags: 
- Others
categories: 
- 建站
---
# 代码块
> 虽然是代码块，但是也能放其他东西（和文章的要求没什么区别）。

:::warning 
避坑指南：
- 每个代码块的结尾标记和前面后面必须跟空行，否则会出现渲染错误。
- 每个代码块的结尾标记那一行必须只能有`:::`三个英文半角冒号，否则会出现渲染错误。

:::

## 隐藏/折叠代码块
### 格式
```
:::details [block title]
[Custom text goes here]

:::

```
### 实例
:::details 点击此处查看已折叠内容(这里的可以自定义哦～)
This is a hidden code.
This is a custom **plaintext**.

:::

----

## 