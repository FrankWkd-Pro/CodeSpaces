#include <bits/stdc++.h>
using namespace std;

const int N = 5e5 + 10;
struct node {
    int from, to, next;
} a[N];
int pre[N], k = 0;

int din[N], g;  // 统计入度
typedef pair<int, int> PII;
map<PII, int> f;  // 标记边是否被摧毁

void add(int u, int v) {
    a[++k] = {u, v, pre[u]};
    pre[u] = k;
}

int main() {
    int n, m, q, t, x, y;
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= m; i++) {
        scanf("%d%d", &x, &y);
        add(y, x);      // 反向建边，方便维护
        din[y]++;       // 出度变入度
        f[{y, x}] = 1;  // 标记边是存在的
    }
    scanf("%d", &q);
    while (q--) {
        scanf("%d%d", &t, &x);
        if (t == 1 || t == 3)
            scanf("%d", &y);
        if (t == 1) {
            din[y]--;
            f[{y, x}] = 2;  // 损坏
        } else if (t == 2) {
            // 摧毁 x 所有的出边
            for (int i = pre[x]; i; i = a[i].next) {
                int to = a[i].to;
                // 如果本来是好的，则摧毁
                if (f[{x, to}] == 1) {
                    din[to]--;
                    f[{x, to}] = 2;
                }
            }
        } else if (t == 3) {
            f[{y, x}] = 1;
            din[y]++;
        } else if (t == 4) {
            for (int i = pre[x]; i; i = a[i].next) {
                int to = a[i].to;
                if (f[{x, to}] == 2) {
                    din[to]++;
                    f[{x, to}] = 1;
                }
            }
        }
    }
    // 如果所有点出度为1
    bool flag = true;
    for (int i = 1; i <= n; i++) {
        if (din[i] != 1) {
            flag = false;
            break;
        }
    }
    // 输出入度（这里原代码注释部分，按逻辑补全输出）
    for (int i = 1; i <= n; i++) {
        cout << din[i] << " ";
    }
    cout << endl;
    if (flag)
        puts("YES");
    else
        puts("NO");
    return 0;
}
